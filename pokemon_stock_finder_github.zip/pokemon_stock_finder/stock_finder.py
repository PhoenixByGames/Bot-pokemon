#!/usr/bin/env python3
"""UK Pokémon TCG stock watcher and resale-margin calculator.

Checks retailer product pages supplied in config.json. It does not bypass
CAPTCHAs, logins, queues, or access controls. Retailer HTML changes often;
selectors must be checked and maintained by the user.

Sold-price evidence is supplied in data/sold_comps.csv. The bot deliberately
does not treat active asking prices as sold prices.
"""
from __future__ import annotations
import csv, json, os, re, smtplib, sys
from dataclasses import dataclass, asdict
from email.message import EmailMessage
from pathlib import Path
from statistics import median
from typing import Optional
import requests
from bs4 import BeautifulSoup

ROOT = Path(__file__).parent
CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; PokemonStockFinder/1.0; +https://github.com/)"}

@dataclass
class Finding:
    product: str
    retailer: str
    url: str
    price: float
    stock: str
    sold_median: Optional[float]
    sold_low: Optional[float]
    sold_high: Optional[float]
    sold_samples: int
    fees: float
    postage: float
    packaging: float
    net_profit: Optional[float]
    roi_percent: Optional[float]

def money(value):
    if value is None: return None
    try:
        return round(float(re.sub(r"[^0-9.]", "", str(value))), 2)
    except (ValueError, TypeError):
        return None

def load_sold_comps():
    path = ROOT / "data" / "sold_comps.csv"
    comps = {}
    if not path.exists(): return comps
    with path.open(newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            key = row.get("product", "").strip().casefold()
            price = money(row.get("sold_price"))
            if key and price:
                comps.setdefault(key, []).append(price)
    return comps

def extract_text(soup, selector):
    if not selector: return ""
    node = soup.select_one(selector)
    return node.get_text(" ", strip=True) if node else ""

def check_page(item):
    response = requests.get(item["url"], headers=HEADERS, timeout=20)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    price_text = extract_text(soup, item.get("price_selector"))
    stock_text = extract_text(soup, item.get("stock_selector"))
    price = money(price_text)
    if price is None:
        raise ValueError(f"No price found using selector {item.get('price_selector')!r}")
    stock_map = item.get("stock_keywords", {"in_stock": ["in stock", "add to basket", "add to cart"],
                                           "out_of_stock": ["out of stock", "sold out", "unavailable"]})
    stock_lower = stock_text.casefold()
    if any(x in stock_lower for x in stock_map["out_of_stock"]):
        stock = "OUT_OF_STOCK"
    elif any(x in stock_lower for x in stock_map["in_stock"]):
        stock = "IN_STOCK"
    else:
        stock = "UNKNOWN"
    return price, stock

def calculate(item, price, sold_prices):
    vals = sold_prices.get(item["name"].casefold(), [])
    if not vals: return None, None, None, 0, None, None
    mid = median(vals)
    low, high = min(vals), max(vals)
    # Configurable estimate; not an exact platform quote. Set to your actual fee rate.
    fee_rate = float(CONFIG.get("selling_fee_rate", 0.13))
    fee_fixed = float(CONFIG.get("selling_fee_fixed", 0.30))
    postage = float(item.get("postage_cost", CONFIG.get("default_postage", 3.49)))
    packaging = float(item.get("packaging_cost", CONFIG.get("default_packaging", 0.40)))
    # Assume buyer pays the same postage amount; sale price is the item price only.
    fees = mid * fee_rate + fee_fixed
    profit = mid - price - fees - postage - packaging
    roi = (profit / price * 100) if price else None
    return mid, low, high, len(vals), fees, (profit, roi, postage, packaging)

def send_email(subject, body):
    host = os.getenv("SMTP_HOST")
    if not host or not os.getenv("ALERT_TO"):
        print("Email not configured; printing report only.")
        return
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = os.getenv("ALERT_FROM", os.getenv("SMTP_USER", "bot@example.com"))
    msg["To"] = os.environ["ALERT_TO"]
    msg.set_content(body)
    with smtplib.SMTP(host, int(os.getenv("SMTP_PORT", "587"))) as server:
        server.starttls()
        if os.getenv("SMTP_USER"):
            server.login(os.environ["SMTP_USER"], os.environ["SMTP_PASSWORD"])
        server.send_message(msg)

def main():
    sold = load_sold_comps()
    budget = float(CONFIG.get("total_budget", 100))
    min_profit = float(CONFIG.get("minimum_net_profit", 10))
    findings = []
    errors = []
    for item in CONFIG["products"]:
        try:
            price, stock = check_page(item)
            mid, low, high, n, fees, calc = calculate(item, price, sold)
            if calc:
                profit, roi, postage, packaging = calc
            else:
                profit = roi = fees = None
                postage = float(item.get("postage_cost", CONFIG.get("default_postage", 3.49)))
                packaging = float(item.get("packaging_cost", CONFIG.get("default_packaging", .40)))
            findings.append(Finding(item["name"], item["retailer"], item["url"], price, stock,
                mid, low, high, n, fees, postage, packaging, profit, roi))
        except Exception as exc:
            errors.append(f'{item.get("name", item["url"])}: {exc}')

    # Only alert on confirmed in-stock, supported sold comps, budget-fit and profitable products.
    qualified = [x for x in findings if x.stock == "IN_STOCK" and x.sold_samples >= 3
                 and x.net_profit is not None and x.net_profit >= min_profit and x.price <= budget]
    qualified.sort(key=lambda x: x.net_profit or -999, reverse=True)

    print(f"Pokémon Stock Finder | budget £{budget:.2f} | minimum net profit £{min_profit:.2f}")
    for x in findings:
        print(f"\n{x.product} — {x.retailer}\n  {x.stock} | buy £{x.price:.2f} | sold median "
              f"{'£%.2f'%x.sold_median if x.sold_median else 'NO SOLD DATA'} "
              f"({x.sold_samples} samples)")
        if x.net_profit is not None:
            print(f"  sold range £{x.sold_low:.2f}–£{x.sold_high:.2f}; estimated fees "
                  f"£{x.fees:.2f}; postage £{x.postage:.2f}; packaging £{x.packaging:.2f}; "
                  f"net £{x.net_profit:.2f}; ROI {x.roi_percent:.1f}%")
        print(f"  {x.url}")
    if errors:
        print("\nCHECK ERRORS (site may have changed or blocked automated requests):")
        print("\n".join(errors))

    if qualified:
        lines = ["Confirmed-stock resale opportunities:"]
        for x in qualified:
            lines.append(f"\n{x.product} ({x.retailer})\nBuy: £{x.price:.2f} | "
                         f"eBay sold median: £{x.sold_median:.2f} from {x.sold_samples} records | "
                         f"estimated net: £{x.net_profit:.2f} ({x.roi_percent:.1f}% ROI)\n{x.url}")
        send_email("Pokémon stock opportunity found", "\n".join(lines))
    else:
        print("\nNo qualifying opportunity. No alert sent.")

    # Save a machine-readable report for the GitHub Actions artifact/log.
    (ROOT / "latest_report.json").write_text(
        json.dumps([asdict(x) for x in findings], indent=2), encoding="utf-8"
    )

if __name__ == "__main__":
    main()
