# Pokémon Stock Finder (UK)

A configurable Python starter bot for checking UK Pokémon TCG product pages, comparing them with manually maintained UK eBay sold-price samples, and estimating resale profit.

## Important limitations

- Retailer websites change their HTML frequently. You must configure selectors in `config.json` for each product page.
- Respect each retailer's terms, robots.txt, rate limits and access controls. Do not bypass CAPTCHAs, queues, logins or anti-bot protections.
- Stock status is only as reliable as the page's visible stock text. `UNKNOWN` is not treated as available.
- The bot does **not** scrape eBay sold listings. Add genuine completed-sale data to `data/sold_comps.csv`. Never use active asking prices as sold prices.
- The fee rate is an estimate. Update it to match your selling account/category and current eBay fees. Actual postage, returns and tax can change profit.
- The example product and sold prices are placeholders only. Delete them and add real evidence before relying on results.

## Setup

1. Create a GitHub repository and upload these files.
2. Edit `config.json`: replace the example product with real retailer product URLs, CSS selectors, product names and postage assumptions.
3. Replace the example rows in `data/sold_comps.csv` with at least three recent UK sold examples for the exact product, same condition and preferably the same language/region.
4. Run locally:

   ```bash
   python -m pip install -r requirements.txt
   python stock_finder.py
   ```

5. In GitHub, enable **Actions** for the repository. The workflow checks hourly and can also be run manually from the Actions tab.

## Email alerts (optional)

In repository **Settings → Secrets and variables → Actions**, add:

- `SMTP_HOST`
- `SMTP_PORT` (usually `587`)
- `SMTP_USER`
- `SMTP_PASSWORD`
- `ALERT_FROM`
- `ALERT_TO`

Use an email provider/app password. Never put passwords or API keys in source files.

## Profit calculation

`estimated net = median sold price - purchase price - (median sold price × fee rate + fixed fee) - postage - packaging`

Only products marked `IN_STOCK`, with at least three sold-price records, purchase price within budget and estimated net profit at or above the configured threshold trigger an email.

## Retailer configuration

Example config entry:

```json
{
  "name": "Pokémon Booster Bundle – Example Set",
  "retailer": "Retailer name",
  "url": "https://retailer.example/product",
  "price_selector": "[data-testid='price']",
  "stock_selector": ".availability",
  "postage_cost": 3.49,
  "packaging_cost": 0.40
}
```

Inspect the retailer's public product page to identify appropriate CSS selectors. If the retailer provides an official product feed or API, prefer that over HTML parsing.
